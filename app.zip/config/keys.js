module.exports = {
    KEY: 'your_key_here',
    REQUEST_KEY: 'your_request_key_here'
};
